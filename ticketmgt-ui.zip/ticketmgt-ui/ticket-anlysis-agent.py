"""
Install the required libraries
pip install langchain google-generativeai mysql-connector-python langchain-community

"""

import os
import re
from dotenv import load_dotenv
import mysql.connector
from langchain.chat_models import ChatGoogleGenerativeAI
from langchain.schema import HumanMessage
from langchain.memory import ConversationBufferMemory
from langchain.chains import ConversationChain

# Load environment variables
load_dotenv()

# Environment configuration
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
DB_HOST = os.getenv("DB_HOST")
DB_USER = os.getenv("DB_USER")
DB_PASSWORD = os.getenv("DB_PASSWORD")
DB_NAME = os.getenv("DB_NAME")

# Configure Gemini LLM
os.environ["GOOGLE_API_KEY"] = GEMINI_API_KEY
llm = ChatGoogleGenerativeAI(model="gemini-pro", temperature=0.3)

# Setup LangChain memory
memory = ConversationBufferMemory(return_messages=True)
conversation = ConversationChain(llm=llm, memory=memory)

# MySQL Connection
def connect_mysql():
    return mysql.connector.connect(
        host=DB_HOST,
        user=DB_USER,
        password=DB_PASSWORD,
        database=DB_NAME
    )

# Validate if user input is about ticket data
def validate_ticket_query(user_input):
    prompt = f"""Is this user query about ticket data? Respond only with Yes or No.
Query: "{user_input}"."""
    result = llm.invoke([HumanMessage(content=prompt)]).content.strip()
    return result.lower().startswith("yes")

# Generate SQL from user input using Gemini
def generate_sql_query(user_input):
    prompt = f"""
Convert the following into a MySQL query for a table named `tickets` with columns:
- id
- title
- description
- category
- issue_date
- status

User Query: {user_input}
Return only the SQL query without explanations or markdown."""
    result = llm.invoke([HumanMessage(content=prompt)]).content.strip()
    return re.sub(r"```sql|```", "", result).strip()

# Execute the generated SQL
def execute_sql(sql):
    try:
        conn = connect_mysql()
        cursor = conn.cursor()
        cursor.execute(sql)
        rows = cursor.fetchall()
        headers = [col[0] for col in cursor.description]
        cursor.close()
        conn.close()
        return headers, rows
    except mysql.connector.Error as err:
        return None, f"MySQL Error: {err}"

# Summarize the SQL result using Gemini
def summarize_result(headers, rows):
    if not rows:
        return "No data found for this query."

    preview = "\n".join([", ".join(map(str, row)) for row in rows[:10]])
    prompt = f"""You are a ticket data analyst. Given the following table data:
Columns: {headers}
Rows:
{preview}
Generate a short, insightful summary."""
    return llm.invoke([HumanMessage(content=prompt)]).content.strip()

# Main Agent Loop
def agent_loop():
    print("LangChain Gemini Ticket Agent")
    print("Type 'exit' to stop.")

    while True:
        user_input = input("\nUser: ")
        if user_input.lower() in ['exit', 'quit']:
            print("Exiting...")
            break

        if not validate_ticket_query(user_input):
            print("Not a valid ticket-related query. Please try again.")
            continue

        memory.chat_memory.add_user_message(user_input)

        sql = generate_sql_query(user_input)
        print(f"\nGenerated SQL:\n{sql}")

        headers, result = execute_sql(sql)
        if not headers:
            print(result)
            continue

        summary = summarize_result(headers, result)
        memory.chat_memory.add_ai_message(summary)
        print(f"\nSummary:\n{summary}")

# Entry Point
if __name__ == "__main__":
    agent_loop()
